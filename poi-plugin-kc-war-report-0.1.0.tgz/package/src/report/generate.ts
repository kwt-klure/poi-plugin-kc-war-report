import { buildFleetCompositionText, toSimpleKanji } from '../battle/model'
import type { BattleFacts, GeneratedWarReport } from '../battle/types'

const pickVariant = (seed: number, variants: readonly string[]) =>
  variants[Math.abs(seed) % variants.length] ?? variants[0]

const toJapaneseDate = (timestamp: number) => {
  const date = new Date(timestamp)
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()

  if (year >= 2019) {
    return `令和${toSimpleKanji(year - 2018)}年${toSimpleKanji(month)}月${toSimpleKanji(day)}日`
  }

  return `${year}年${month}月${day}日`
}

const getResultPhrase = (facts: BattleFacts) => {
  const rank = facts.winRank ?? ''
  if (facts.kind === 'practice') {
    if (rank === 'S') {
      return '対抗演習ヲ完遂シ、優秀ナル成績ヲ収メタリ'
    }
    if (rank === 'A') {
      return '対抗演習ヲ完遂シ、所期ノ成果ヲ収メタリ'
    }
    return '対抗演習ヲ実施シ、戦技ノ研鑽ヲ遂ゲタリ'
  }

  if (rank === 'S') {
    return '之ニ対シ顕著ナル戦果ヲ収メ、所定任務ヲ完遂セリ'
  }
  if (rank === 'A') {
    return '之ニ対シ相当ノ戦果ヲ収メ、任務ヲ達成セリ'
  }
  if (rank === 'B') {
    return '之ト交戦シ、隊形ヲ保持シツツ任務ヲ遂行セリ'
  }
  if (rank === 'C' || rank === 'D') {
    return '之ト交戦シ、若干ノ損害ヲ被リツツモ任務継続ノ態勢ヲ維持セリ'
  }
  return '之ト交戦シ、所定ノ行動ヲ継続セリ'
}

const buildHeadline = (facts: BattleFacts) => {
  if (facts.kind === 'practice') {
    return '演習部隊、対抗演習ヲ完遂'
  }

  const enemyPhrase = facts.sawAirAttack ? '敵航空兵力ヲ撃退シ' : '敵兵力ト交戦シ'
  const missionPhrase =
    facts.mode === 'boss' ? '主目標方面ニ於テ' : facts.mapLabel ? `${facts.mapLabel}方面ニ於テ` : '作戦海域ニ於テ'
  return `出撃部隊、${missionPhrase}${enemyPhrase}任務ヲ完遂`
}

const buildOpeningParagraph = (facts: BattleFacts) => {
  const enemyClause = facts.enemyDeckName
    ? `敵${facts.enemyDeckName}ト相見エ`
    : facts.sawAirAttack
      ? '来襲セル敵航空兵力並ニ敵水上兵力ト交戦シ'
      : '敵兵力ト交戦シ'

  if (facts.kind === 'practice') {
    return `帝国海軍演習部隊ノ一部ハ、${toJapaneseDate(
      facts.occurredAt,
    )}、対抗演習実施中、${facts.practiceOpponent ?? '対抗部隊'}ニ対シ所定ノ演習行動ヲ実施シ、${getResultPhrase(
      facts,
    )}。`
  }

  return `帝国海軍出撃部隊ノ一部ハ、${toJapaneseDate(
    facts.occurredAt,
  )}、${facts.operationLabel}ニ於ケル行動中、${enemyClause}、${getResultPhrase(facts)}。`
}

const buildCompositionParagraph = (facts: BattleFacts) => {
  const base = `当時我部隊兵力ハ、${buildFleetCompositionText(
    facts.fleetShips,
  )}ヲ基幹トスル兵力ニシテ、旗艦「${facts.flagshipName ?? '不詳'}」ノ指揮ノ下、沈着機敏ニ行動セリ。`

  if (facts.antiAirScreen) {
    return `${base}殊ニ秋月型駆逐艦ヲ中核トスル防空火網ハ緊密ニシテ、敵航空攻撃企図ヲ挫折セシムルニ大イニ寄与セリ。`
  }

  return `${base}各艦ハ統制宜シク、戦機ニ応ジ迅速適切ナル行動ヲ執リタリ。`
}

const buildDamageParagraph = (facts: BattleFacts) => {
  const damageSentence =
    facts.damageSeverity === 'none'
      ? '我方各艦ハ一艦ノ損傷モ無ク、航行並ニ戦闘能力ヲ完全ニ保持セリ。'
      : facts.damageSeverity === 'light'
        ? '我方一部艦艇ニ軽微ナル損傷アリシモ、隊形・任務遂行ニ支障ナシ。'
        : facts.damageSeverity === 'moderate'
          ? '我方一部艦艇ニ相応ノ損傷アリシモ、部隊ハ統制ヲ失ハズ任務継続可能ノ態勢ヲ保テリ。'
          : facts.damageSeverity === 'heavy'
            ? '我方相応ノ損害ヲ蒙リタルモ、部隊ハ隊形ヲ維持シ所定行動ヲ継続セリ。'
            : '我方損害ノ細部ハ目下調査中ナルモ、任務遂行態勢ハ保持セリ。'

  const resultNote = facts.damageDetail.startsWith('損傷艦:')
    ? ` ${facts.damageDetail}。`
    : ''

  return `戦闘後ノ状況ニ依レバ、${facts.enemyDisplay}ハ我部隊ノ攻撃ニ依リ攻勢ヲ達成スル能ハズ、${damageSentence}${resultNote}`
}

const buildClosingParagraph = (facts: BattleFacts) => {
  const emphasis = facts.antiAirScreen
    ? '防空戦闘力ノ優秀'
    : facts.kind === 'practice'
      ? '部隊練度ノ充実'
      : '各艦乗員ノ沈着勇戦'

  return `本戦果ハ、${emphasis}並ニ平素ノ訓練成果ニ負フ所大ナリ。大本営ハ本行動ニ於ケル部隊ノ奮戦ヲ嘉シ、其武功ヲ広ク周知セシムルモノナリ。`
}

export const generateWarReport = (facts: BattleFacts): GeneratedWarReport => {
  const seed = facts.occurredAt
  const banner = [
    '海軍省提供',
    '',
    toJapaneseDate(facts.occurredAt),
    '',
    buildHeadline(facts),
    '',
    facts.damageLabel,
    '',
    '【大本営海軍報道部発表】',
  ].join('\n')

  const intro = buildOpeningParagraph(facts)
  const body = [
    '【大本営海軍報道部発表】',
    '',
    intro,
    '',
    buildCompositionParagraph(facts),
    '',
    buildDamageParagraph(facts),
    '',
    pickVariant(seed, [buildClosingParagraph(facts)]),
  ].join('\n')

  return {
    bulletin: banner,
    body,
  }
}
