export type BattleKind = 'sortie' | 'practice'

export type BattleMode = 'normal' | 'boss' | 'practice'

export type DamageSeverity = 'none' | 'light' | 'moderate' | 'heavy' | 'unknown'

export type FleetShipSnapshot = {
  instanceId: number
  shipId: number
  nameJa: string
  typeId: number | null
  typeNameJa: string | null
  level: number
  startHp: number
  endHp: number | null
  maxHp: number
}

export type BattleFacts = {
  occurredAt: number
  kind: BattleKind
  mode: BattleMode
  operationLabel: string
  mapLabel: string | null
  enemyDisplay: string
  enemyDeckName: string | null
  enemyShipNames: string[]
  fleetShips: FleetShipSnapshot[]
  fleetComposition: string
  flagshipName: string | null
  winRank: string | null
  damageSeverity: DamageSeverity
  damageLabel: string
  damageDetail: string
  sawAirAttack: boolean
  antiAirScreen: boolean
  practiceOpponent: string | null
}

export type GeneratedWarReport = {
  bulletin: string
  body: string
}

export type WarReportSnapshot = {
  facts: BattleFacts
  report: GeneratedWarReport
}
