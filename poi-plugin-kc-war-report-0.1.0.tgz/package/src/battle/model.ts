import type { DamageSeverity, FleetShipSnapshot } from './types'

const kanjiDigits = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九'] as const

export const toSimpleKanji = (value: number) => {
  if (value <= 10) {
    if (value === 10) {
      return '十'
    }
    return kanjiDigits[value] ?? String(value)
  }

  if (value < 20) {
    return `十${kanjiDigits[value - 10]}`
  }

  return String(value)
}

export const formatShipCount = (value: number) =>
  value === 1 ? '一隻' : `${toSimpleKanji(value)}隻`

export const buildFleetCompositionText = (ships: FleetShipSnapshot[]) => {
  if (ships.length === 0) {
    return '艦隊編成情報不詳'
  }

  const counts = new Map<string, number>()
  for (const ship of ships) {
    const label = ship.typeNameJa ?? ship.nameJa
    counts.set(label, (counts.get(label) ?? 0) + 1)
  }

  return Array.from(counts.entries())
    .map(([label, count]) => `${label}${formatShipCount(count)}`)
    .join('、')
}

const getDamageStateLabel = (ship: FleetShipSnapshot) => {
  if (ship.endHp == null) {
    return null
  }
  const ratio = ship.endHp / ship.maxHp
  if (ratio <= 0.25) {
    return '大破'
  }
  if (ratio <= 0.5) {
    return '中破'
  }
  if (ratio < 1) {
    return '小破'
  }
  return null
}

export const buildDamageAssessment = (
  ships: FleetShipSnapshot[],
): { severity: DamageSeverity; label: string; detail: string } => {
  if (ships.length === 0 || ships.every((ship) => ship.endHp == null)) {
    return {
      severity: 'unknown',
      label: '損害詳報未着',
      detail: '我方損害の細部は目下整理中。',
    }
  }

  const damagedShips = ships
    .map((ship) => ({
      ship,
      loss: ship.endHp == null ? 0 : Math.max(0, ship.startHp - ship.endHp),
      state: getDamageStateLabel(ship),
    }))
    .filter((entry) => entry.loss > 0)

  if (damagedShips.length === 0) {
    return {
      severity: 'none',
      label: '我方損害ナシ',
      detail: '我方各艦に損害なし。',
    }
  }

  const hasHeavy = damagedShips.some((entry) => entry.state === '大破')
  const hasModerate = damagedShips.some((entry) => entry.state === '中破')
  const severity: DamageSeverity = hasHeavy ? 'heavy' : hasModerate ? 'moderate' : 'light'
  const label =
    severity === 'heavy'
      ? '我方相応ノ損害'
      : severity === 'moderate'
        ? '我方一部損傷'
        : '我方軽微ノ損害'

  const detail = damagedShips
    .slice(0, 4)
    .map(({ ship, state }) => `${ship.nameJa}${state ? `(${state})` : ''}`)
    .join('、')

  return {
    severity,
    label,
    detail: `損傷艦: ${detail}${damagedShips.length > 4 ? ' 他' : ''}`,
  }
}

export const buildEnemyDisplay = (enemyDeckName: string | null, enemyShipNames: string[]) => {
  if (enemyDeckName) {
    return `敵「${enemyDeckName}」`
  }

  const unique = Array.from(new Set(enemyShipNames.filter(Boolean)))
  if (unique.length === 0) {
    return '敵兵力若干'
  }

  if (unique.length === 1) {
    return `敵「${unique[0]}」`
  }

  return `敵「${unique.slice(0, 2).join('」「')}」等`
}
