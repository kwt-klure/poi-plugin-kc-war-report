import { useSyncExternalStore } from 'react'

import { buildDamageAssessment, buildEnemyDisplay, buildFleetCompositionText } from './model'
import { generateWarReport } from '../report/generate'
import { IN_POI } from '../poi/env'
import { getStoreValue } from '../poi/store'
import type { PoiFleet, PoiShip, PoiShipMaster, PoiShipTypeMaster } from '../poi/types'
import type {
  BattleFacts,
  BattleMode,
  FleetShipSnapshot,
  WarReportSnapshot,
} from './types'

type GameResponseDetail = {
  path: string
  body: Record<string, unknown>
  postBody?: Record<string, string>
  time?: number
}

type GameResponseEvent = CustomEvent<GameResponseDetail>

type ResultBody = {
  api_win_rank?: string
  api_quest_name?: string
  api_enemy_info?: {
    api_deck_name?: string
  }
}

type BattlePacket = {
  api_ship_ke?: number[]
  api_kouku?: unknown
  api_injection_kouku?: unknown
  api_air_base_attack?: unknown[]
  api_friendly_kouku?: unknown
}

type CurrentBattleContext = {
  occurredAt: number
  kind: 'sortie' | 'practice'
  mode: BattleMode
  deckId: number
  map: [number, number, number] | null
  fleetShips: FleetShipSnapshot[]
  practiceOpponent: string | null
  enemyShipIds: number[]
  sawAirAttack: boolean
}

let currentBattle: CurrentBattleContext | null = null
let latestSnapshot: WarReportSnapshot | null = null
let practiceOpponent: string | null = null
let finalizeTimer: ReturnType<typeof setTimeout> | null = null
let listening = false

const subscribers = new Set<() => void>()

const emitChange = () => {
  for (const subscriber of subscribers) {
    subscriber()
  }
}

const getArrayValue = <T>(value: Record<string, T> | T[] | null | undefined, id: string | number) => {
  if (!value) {
    return null
  }

  if (Array.isArray(value)) {
    return value[Number(id)] ?? null
  }

  return value[String(id)] ?? null
}

const captureShipSnapshot = (shipInstanceId: number): FleetShipSnapshot | null => {
  const ship = getStoreValue<PoiShip>(['info', 'ships', shipInstanceId])
  if (!ship?.api_ship_id || ship.api_nowhp == null || ship.api_maxhp == null) {
    return null
  }

  const master = getStoreValue<Record<string, PoiShipMaster> | PoiShipMaster[]>([
    'const',
    '$ships',
  ])
  const shipMaster = getArrayValue(master ?? null, ship.api_ship_id)
  const shipTypes = getStoreValue<Record<string, PoiShipTypeMaster> | PoiShipTypeMaster[]>([
    'const',
    '$shipTypes',
  ])
  const shipTypeMaster =
    shipMaster?.api_stype != null ? getArrayValue(shipTypes ?? null, shipMaster.api_stype) : null

  return {
    instanceId: shipInstanceId,
    shipId: ship.api_ship_id,
    nameJa: shipMaster?.api_name ?? `艦ID ${ship.api_ship_id}`,
    typeId: shipMaster?.api_stype ?? null,
    typeNameJa: shipTypeMaster?.api_name ?? null,
    level: ship.api_lv ?? 0,
    startHp: ship.api_nowhp,
    endHp: null,
    maxHp: ship.api_maxhp,
  }
}

const captureFleetSnapshot = (deckId: number): FleetShipSnapshot[] => {
  const fleet =
    getStoreValue<PoiFleet>(['info', 'fleets', deckId - 1]) ??
    getStoreValue<PoiFleet>(['info', 'decks', deckId - 1]) ??
    getStoreValue<PoiFleet>(['info', 'fleets', deckId]) ??
    getStoreValue<PoiFleet>(['info', 'decks', deckId])

  const shipIds = (fleet?.api_ship ?? []).filter((value): value is number => typeof value === 'number' && value > 0)
  return shipIds
    .map((shipInstanceId) => captureShipSnapshot(shipInstanceId))
    .filter((ship): ship is FleetShipSnapshot => ship != null)
}

const updateFleetEndHp = (ships: FleetShipSnapshot[]): FleetShipSnapshot[] =>
  ships.map((ship) => {
    const latestShip = getStoreValue<PoiShip>(['info', 'ships', ship.instanceId])
    return {
      ...ship,
      endHp: latestShip?.api_nowhp ?? ship.endHp,
    }
  })

const getEnemyShipNames = (enemyShipIds: number[]) => {
  const masters = getStoreValue<Record<string, PoiShipMaster> | PoiShipMaster[]>(['const', '$ships'])
  return enemyShipIds
    .filter((shipId) => shipId > 0)
    .map((shipId) => getArrayValue(masters ?? null, shipId)?.api_name ?? `敵艦ID ${shipId}`)
}

const buildFacts = (
  context: CurrentBattleContext,
  resultBody: ResultBody,
): BattleFacts => {
  const fleetShips = updateFleetEndHp(context.fleetShips)
  const damage = buildDamageAssessment(fleetShips)
  const enemyShipNames = getEnemyShipNames(context.enemyShipIds)
  const enemyDeckName = resultBody.api_enemy_info?.api_deck_name ?? null
  const enemyDisplay = buildEnemyDisplay(enemyDeckName, enemyShipNames)
  const operationLabel =
    context.kind === 'practice'
      ? `演習: ${context.practiceOpponent ?? '対抗部隊'}`
      : resultBody.api_quest_name ??
        (context.map ? `${context.map[0]}-${context.map[1]} 海域` : '出撃海域')

  const antiAirScreen =
    context.sawAirAttack &&
    fleetShips.filter((ship) => ship.nameJa.includes('秋月') || ship.nameJa.includes('照月') || ship.nameJa.includes('涼月') || ship.nameJa.includes('初月') || ship.nameJa.includes('冬月') || ship.nameJa.includes('満月')).length >= 2

  return {
    occurredAt: context.occurredAt,
    kind: context.kind,
    mode: context.mode,
    operationLabel,
    mapLabel: context.map ? `${context.map[0]}-${context.map[1]}` : null,
    enemyDisplay,
    enemyDeckName,
    enemyShipNames,
    fleetShips,
    fleetComposition: buildFleetCompositionText(fleetShips),
    flagshipName: fleetShips[0]?.nameJa ?? null,
    winRank: resultBody.api_win_rank ?? null,
    damageSeverity: damage.severity,
    damageLabel: damage.label,
    damageDetail: damage.detail,
    sawAirAttack: context.sawAirAttack,
    antiAirScreen,
    practiceOpponent: context.practiceOpponent,
  }
}

const publishResult = (context: CurrentBattleContext, resultBody: ResultBody) => {
  const facts = buildFacts(context, resultBody)
  latestSnapshot = {
    facts,
    report: generateWarReport(facts),
  }
  emitChange()
}

const scheduleFinalize = (context: CurrentBattleContext, resultBody: ResultBody) => {
  if (finalizeTimer) {
    clearTimeout(finalizeTimer)
  }

  finalizeTimer = setTimeout(() => {
    publishResult(context, resultBody)
    currentBattle = null
    finalizeTimer = null
  }, 120)
}

const createSortieContext = (detail: GameResponseDetail) => {
  const deckId = Number(detail.postBody?.api_deck_id ?? 1)
  currentBattle = {
    occurredAt: detail.time ?? Date.now(),
    kind: 'sortie',
    mode: Number(detail.body.api_event_id) === 5 ? 'boss' : 'normal',
    deckId,
    map: [
      Number(detail.body.api_maparea_id ?? 0),
      Number(detail.body.api_mapinfo_no ?? 0),
      Number(detail.body.api_no ?? 0),
    ],
    fleetShips: captureFleetSnapshot(deckId),
    practiceOpponent: null,
    enemyShipIds: [],
    sawAirAttack: false,
  }
}

const createPracticeContext = (detail: GameResponseDetail) => {
  const deckId = Number(detail.postBody?.api_deck_id ?? 1)
  currentBattle = {
    occurredAt: detail.time ?? Date.now(),
    kind: 'practice',
    mode: 'practice',
    deckId,
    map: null,
    fleetShips: captureFleetSnapshot(deckId),
    practiceOpponent,
    enemyShipIds: [],
    sawAirAttack: false,
  }
}

const updateCurrentBattleFromPacket = (packet: BattlePacket) => {
  if (!currentBattle) {
    return
  }

  if (packet.api_ship_ke && currentBattle.enemyShipIds.length === 0) {
    currentBattle.enemyShipIds = packet.api_ship_ke
  }

  if (
    packet.api_kouku ||
    packet.api_injection_kouku ||
    (Array.isArray(packet.api_air_base_attack) && packet.api_air_base_attack.length > 0) ||
    packet.api_friendly_kouku
  ) {
    currentBattle.sawAirAttack = true
  }
}

const handleGameResponse = (event: Event) => {
  const detail = (event as GameResponseEvent).detail
  if (!detail?.path || !detail.body) {
    return
  }

  if (detail.path === '/kcsapi/api_req_member/get_practice_enemyinfo') {
    const nickname = String(detail.body.api_nickname ?? '')
    const level = String(detail.body.api_level ?? '')
    practiceOpponent = nickname ? `${nickname}${level ? ` (Lv.${level})` : ''}` : null
    return
  }

  if (
    detail.path === '/kcsapi/api_req_map/start' ||
    detail.path === '/kcsapi/api_req_map/next'
  ) {
    createSortieContext(detail)
    return
  }

  if (detail.path === '/kcsapi/api_req_practice/battle') {
    createPracticeContext(detail)
    return
  }

  if (!currentBattle) {
    return
  }

  updateCurrentBattleFromPacket(detail.body as BattlePacket)

  if (detail.path.includes('result')) {
    scheduleFinalize(currentBattle, detail.body as ResultBody)
  }
}

export const startBattleListener = () => {
  if (listening || !IN_POI) {
    return
  }
  listening = true
  window.addEventListener('game.response', handleGameResponse as EventListener)
}

export const stopBattleListener = () => {
  if (!listening) {
    return
  }
  listening = false
  if (finalizeTimer) {
    clearTimeout(finalizeTimer)
    finalizeTimer = null
  }
  currentBattle = null
  practiceOpponent = null
  window.removeEventListener('game.response', handleGameResponse as EventListener)
}

export const getLatestWarReportSnapshot = () => latestSnapshot

export const subscribeLatestWarReport = (listener: () => void) => {
  subscribers.add(listener)
  return () => {
    subscribers.delete(listener)
  }
}

export const useLatestWarReport = () =>
  useSyncExternalStore(subscribeLatestWarReport, getLatestWarReportSnapshot, () => null)
