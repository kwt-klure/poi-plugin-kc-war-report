import {
  Button,
  Callout,
  H3,
  H5,
  Intent,
  OverlaysProvider,
  Tag,
  Text,
} from '@blueprintjs/core'
import { IconNames } from '@blueprintjs/icons'
import React, { StrictMode, useCallback, useMemo, useState } from 'react'
import styled from 'styled-components'

import { useLatestWarReport } from './battle/runtime'
import type { DamageSeverity } from './battle/types'
import { buildPlainTextReport, copyReportToClipboard, exportReportToFile } from './export'
import { IN_POI } from './poi/env'
import { usePluginTranslation } from './poi/hooks'
import { tips } from './poi/utils'

const Page = styled.div`
  min-height: 100%;
  padding: 24px;
  background:
    radial-gradient(circle at top, rgba(220, 204, 137, 0.12), transparent 40%),
    linear-gradient(180deg, #0d1724 0%, #101e2f 42%, #13263b 100%);
  color: #eef2f6;
`

const Shell = styled.div`
  display: grid;
  gap: 18px;
  width: min(960px, 100%);
  margin: 0 auto;
`

const Hero = styled.div`
  display: grid;
  gap: 10px;
  padding: 22px 24px;
  border: 1px solid rgba(223, 204, 148, 0.2);
  border-radius: 18px;
  background:
    linear-gradient(135deg, rgba(13, 30, 46, 0.96), rgba(17, 35, 54, 0.9)),
    linear-gradient(180deg, rgba(255, 255, 255, 0.02), transparent);
  box-shadow: 0 22px 54px rgba(0, 0, 0, 0.28);
`

const HeroLine = styled(Text)`
  color: rgba(233, 238, 244, 0.78);
`

const SummaryGrid = styled.div`
  display: grid;
  gap: 18px;
  grid-template-columns: minmax(0, 280px) minmax(0, 1fr);

  @media (max-width: 860px) {
    grid-template-columns: 1fr;
  }
`

const FactsCard = styled.div`
  display: grid;
  gap: 14px;
  padding: 18px;
  border: 1px solid rgba(127, 155, 183, 0.22);
  border-radius: 16px;
  background: rgba(11, 20, 32, 0.72);
`

const FactList = styled.div`
  display: grid;
  gap: 12px;
`

const FactRow = styled.div`
  display: grid;
  gap: 4px;
`

const FactLabel = styled(Text)`
  font-size: 12px;
  letter-spacing: 0.04em;
  color: rgba(171, 189, 208, 0.82);
  text-transform: uppercase;
`

const FactValue = styled(Text)`
  white-space: pre-wrap;
  color: #f2f5f8;
`

const TagRow = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
`

const Actions = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
`

const ReportCard = styled.div`
  display: grid;
  gap: 16px;
  padding: 18px;
  border: 1px solid rgba(223, 204, 148, 0.14);
  border-radius: 16px;
  background:
    linear-gradient(180deg, rgba(24, 38, 54, 0.96), rgba(18, 29, 44, 0.96)),
    radial-gradient(circle at top, rgba(212, 191, 125, 0.07), transparent 45%);
`

const ReportBody = styled.pre`
  margin: 0;
  padding: 18px;
  border-radius: 14px;
  border: 1px solid rgba(214, 193, 132, 0.16);
  background: rgba(9, 15, 24, 0.88);
  white-space: pre-wrap;
  word-break: break-word;
  font-family: 'Hiragino Mincho ProN', 'Yu Mincho', 'Noto Serif JP', serif;
  line-height: 1.9;
  color: #f4ead3;
`

const EmptyState = styled(Callout)`
  background: rgba(18, 29, 44, 0.82);
`

const damageIntentMap: Record<DamageSeverity, Intent> = {
  none: 'success',
  light: 'primary',
  moderate: 'warning',
  heavy: 'danger',
  unknown: 'none',
}

const AppMain: React.FC = () => {
  const { t } = usePluginTranslation()
  const latest = useLatestWarReport()
  const [actionState, setActionState] = useState<{
    intent: Intent | null
    message: string
  }>({
    intent: null,
    message: '',
  })

  const combinedText = useMemo(
    () => (latest ? buildPlainTextReport(latest.report) : ''),
    [latest],
  )

  const handleCopy = useCallback(async () => {
    if (!latest) {
      return
    }
    try {
      await copyReportToClipboard(combinedText)
      setActionState({ intent: 'success', message: t('War report copied') })
      tips.success(t('War report copied'))
    } catch (error) {
      console.error(error)
      setActionState({
        intent: 'danger',
        message:
          error instanceof Error
            ? `${t('Copy failed')}\n${error.message}`
            : t('Copy failed'),
      })
      tips.error(t('Copy failed'))
    }
  }, [combinedText, latest, t])

  const handleExport = useCallback(async () => {
    if (!latest) {
      return
    }
    try {
      const saved = await exportReportToFile(combinedText, latest.facts.occurredAt)
      if (!saved) {
        setActionState({ intent: 'warning', message: t('Export canceled') })
        return
      }
      setActionState({ intent: 'success', message: t('Export success') })
      tips.success(t('Export success'))
    } catch (error) {
      console.error(error)
      setActionState({
        intent: 'danger',
        message:
          error instanceof Error
            ? `${t('Export failed')}\n${error.message}`
            : t('Export failed'),
      })
      tips.error(t('Export failed'))
    }
  }, [combinedText, latest, t])

  return (
    <Page>
      <Shell>
        <Hero>
          <H3>{t('KC War Report')}</H3>
          <HeroLine>{t('War report hero description')}</HeroLine>
          <Callout intent={IN_POI ? 'primary' : 'warning'} icon={IconNames.INFO_SIGN}>
            {IN_POI ? t('War report ready hint') : t('Poi environment required')}
          </Callout>
        </Hero>

        {!latest ? (
          <EmptyState intent="none" icon={IconNames.HISTORY}>
            <H5>{t('No recent battle')}</H5>
            <Text>{t('No recent battle hint')}</Text>
          </EmptyState>
        ) : (
          <SummaryGrid>
            <FactsCard>
              <H5>{t('Latest battle facts')}</H5>
              <TagRow>
                <Tag minimal intent="primary">
                  {latest.facts.winRank ? `${t('Rank')} ${latest.facts.winRank}` : t('Rank unknown')}
                </Tag>
                <Tag minimal intent={damageIntentMap[latest.facts.damageSeverity]}>
                  {latest.facts.damageLabel}
                </Tag>
                <Tag minimal intent={latest.facts.kind === 'practice' ? 'warning' : 'success'}>
                  {latest.facts.kind === 'practice' ? t('Practice') : t('Sortie')}
                </Tag>
              </TagRow>

              <FactList>
                <FactRow>
                  <FactLabel>{t('Operation')}</FactLabel>
                  <FactValue>{latest.facts.operationLabel}</FactValue>
                </FactRow>
                <FactRow>
                  <FactLabel>{t('Friendly Fleet')}</FactLabel>
                  <FactValue>{latest.facts.fleetComposition}</FactValue>
                </FactRow>
                <FactRow>
                  <FactLabel>{t('Enemy')}</FactLabel>
                  <FactValue>{latest.facts.enemyDisplay}</FactValue>
                </FactRow>
                <FactRow>
                  <FactLabel>{t('Damage')}</FactLabel>
                  <FactValue>{latest.facts.damageDetail}</FactValue>
                </FactRow>
              </FactList>

              <Actions>
                <Button
                  intent="primary"
                  icon={IconNames.DUPLICATE}
                  text={t('Copy report')}
                  onClick={handleCopy}
                />
                <Button
                  icon={IconNames.EXPORT}
                  text={t('Export txt')}
                  onClick={handleExport}
                />
              </Actions>

              {actionState.message ? (
                <Callout
                  intent={actionState.intent ?? 'none'}
                  icon={
                    actionState.intent === 'success'
                      ? IconNames.TICK
                      : actionState.intent === 'warning'
                        ? IconNames.WARNING_SIGN
                        : actionState.intent === 'danger'
                          ? IconNames.ERROR
                          : IconNames.INFO_SIGN
                  }
                >
                  <Text style={{ whiteSpace: 'pre-wrap' }}>{actionState.message}</Text>
                </Callout>
              ) : null}
            </FactsCard>

            <ReportCard>
              <H5>{t('Generated report')}</H5>
              <ReportBody>{combinedText}</ReportBody>
            </ReportCard>
          </SummaryGrid>
        )}
      </Shell>
    </Page>
  )
}

export const App = () => (
  <StrictMode>
    <OverlaysProvider>
      <AppMain />
    </OverlaysProvider>
  </StrictMode>
)
