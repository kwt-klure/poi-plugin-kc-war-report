import { Callout, H5, Text } from '@blueprintjs/core'
import React, { StrictMode } from 'react'
import styled from 'styled-components'

import PKG from '../package.json'
import { usePluginTranslation } from './poi/hooks'

const Container = styled.div`
  display: grid;
  gap: 12px;
  padding: 14px;
  user-select: text;
`

const List = styled.ul`
  margin: 0;
  padding-left: 18px;
  color: #43505f;
`

export const SettingsMain = () => {
  const { t } = usePluginTranslation()

  return (
    <Container>
      <H5>{t('KC War Report')}</H5>
      <Text>{t('War report settings description')}</Text>
      <Callout intent="primary">{t('War report settings hint')}</Callout>
      <List>
        <li>{t('Settings limitation latest-only')}</li>
        <li>{t('Settings limitation no-persist')}</li>
        <li>{t('Settings limitation japanese-output')}</li>
        <li>{t('Settings limitation template')}</li>
      </List>
      <Text>{t('Version', { version: PKG.version })}</Text>
    </Container>
  )
}

export const Settings = () => (
  <StrictMode>
    <SettingsMain />
  </StrictMode>
)
