# KC War Report

Standalone Poi plugin that turns the most recent KanColle battle result into a full Japanese war bulletin in a `大本営海軍報道部発表` style.

## Scope

- Reads the most recent battle result after the plugin is enabled
- Generates a short `海軍省提供` bulletin and a longer report body
- Supports copying the generated report and exporting it as a `.txt` file
- Does not use LLMs or external APIs
- Does not persist reports across Poi restarts in v1

## Limits

- The report is template-based and intentionally conservative
- Damage wording is derived from the latest available fleet HP snapshot and may fall back to broad phrasing
- The plugin focuses on the latest single battle result, not full multi-node sortie narratives

## Validation

```bash
npm install
npm run typeCheck
npm test -- --runInBand
```
